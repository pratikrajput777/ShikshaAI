# Day 01: Foundation & Core Infrastructure 🏗️

## 📚 What You Will Achieve Today

By the end of Day 1, you will have:

1. ✅ Complete Django project structure with proper configuration
2. ✅ PostgreSQL database setup with initial schema
3. ✅ Redis and Celery task queue infrastructure
4. ✅ User authentication and authorization system
5. ✅ Core models for Users, Skills taxonomy, and Occupations
6. ✅ Basic API endpoints for user management
7. ✅ Docker containerization (optional but recommended)
8. ✅ Environment configuration and security setup

## 🎯 Learning Objectives

### Backend Fundamentals
- **Django Project Architecture**: Understand app-based modular architecture
- **Django ORM**: Master model relationships (ForeignKey, ManyToMany, OneToOne)
- **PostgreSQL Advanced Features**: Array fields, GIN indexes, full-text search
- **Celery Task Queues**: Async task processing with Redis message broker
- **Environment Management**: Secure configuration with `.env` files

### System Design Concepts
- **Database Design**: Normalization, indexing strategies, and constraints
- **RESTful API Design**: URL patterns, viewsets, and serializers
- **Authentication**: Session-based vs token-based authentication
- **Containerization**: Docker multi-service orchestration

### Security Best Practices
- **Environment Variables**: Never commit secrets to version control
- **CSRF Protection**: Django's built-in CSRF middleware
- **SQL Injection Prevention**: Using ORM instead of raw SQL
- **Password Hashing**: Django's PBKDF2 algorithm

## 🛠️ Technology Stack (Day 1)

| Technology | Version | Purpose |
|------------|---------|---------|
| Django | 4.2.7 | Web framework |
| PostgreSQL | 15+ | Primary database |
| Redis | 5.0.1 | Message broker & caching |
| Celery | 5.3.4 | Distributed task queue |
| Docker | Latest | Containerization |
| Nginx | Latest | Reverse proxy |

## 📊 Database Schema (Day 1)

### Tables to Create
1. **users** - Custom user model with profile fields
2. **user_skills** - User's self-reported skills
3. **user_proficiencies** - IRT-based skill proficiency tracking
4. **occupations** - Job roles from ESCO/O*NET
5. **skills** - Skills taxonomy with semantic embeddings
6. **occupation_skills** - Required skills for each occupation
7. **skill_embeddings** - Vector embeddings for similarity search
8. **skill_synonyms** - Alternative terms for skills

## 📋 Prerequisites

- Python 3.10+ installed
- PostgreSQL 15+ installed and running
- Redis installed and running
- Basic understanding of Python and SQL
- Familiarity with command line
- Text editor/IDE (VS Code, PyCharm, etc.)

## ⏱️ Estimated Time

- **Setup & Installation**: 2 hours
- **Core Models Development**: 3 hours
- **API Endpoints**: 2 hours
- **Testing & Troubleshooting**: 1 hour
- **Total**: ~8 hours (1 working day for 2 developers)

## 🎓 Key Concepts to Master

### 1. Django Apps Architecture
Learn how Django organizes code into reusable apps:
```
project/
├── users/          # User management
├── skills/         # Skills taxonomy
├── assessment/     # IRT assessments
└── core/          # Shared utilities
```

### 2. Django Models
Understand model fields, relationships, and Meta options:
- Field types: CharField, TextField, IntegerField, ForeignKey
- Relationships: OneToOne, ForeignKey, ManyToMany
- Meta options: db_table, indexes, unique_together, ordering

### 3. PostgreSQL-Specific Features
- **ArrayField**: Store lists of values in a single column
- **GIN Indexes**: Fast full-text search on array fields
- **JSONB Fields**: Store structured data as JSON

### 4. Celery Tasks
Understand async task processing:
- Task queues for background jobs
- Beat scheduler for periodic tasks
- Worker processes for task execution

## 📖 Resources for Day 1

### Official Documentation
- [Django Documentation](https://docs.djangoproject.com/en/4.2/)
- [Django Models](https://docs.djangoproject.com/en/4.2/topics/db/models/)
- [PostgreSQL Arrays](https://www.postgresql.org/docs/current/arrays.html)
- [Celery Documentation](https://docs.celeryq.dev/)

### Tutorials
- Django for Beginners (William Vincent)
- Two Scoops of Django (Best Practices)
- PostgreSQL Up and Running

## 🚀 Success Criteria

By end of day, you should be able to:

- [x] Run `python manage.py runserver` successfully
- [x] Access Django admin at `http://localhost:8000/admin/`
- [x] Create users via API endpoint
- [x] View database tables in PostgreSQL
- [x] See Celery worker processing tasks
- [x] Run migrations without errors

## 🎯 Next Steps (Day 2 Preview)

Tomorrow you will implement:
- IRT-based diagnostic assessment engine
- Question bank with difficulty parameters
- Adaptive question selection algorithm
- Skill gap analysis system

---

**Remember**: Take breaks, ask questions, and don't rush. Understanding the fundamentals is crucial for the rest of the project!
