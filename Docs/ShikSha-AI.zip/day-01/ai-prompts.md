# Day 01: AI Agent Prompts

This document contains ready-to-use prompts for AI coding assistants (GitHub Copilot, Cursor, ChatGPT, Claude, etc.) organized by phase and task.

---

## 📋 How to Use These Prompts

1. **Copy the exact prompt** for your current task
2. **Paste into your AI assistant** (Copilot Chat, Cursor, etc.)
3. **Review the generated code** carefully
4. **Test before committing** to version control
5. **Adjust and iterate** if needed

---

## Phase 1: Project Initialization

### Prompt 1.2.1: Create Requirements File

```
Create a requirements.txt file for a Django 4.2.7 project with the following dependencies:
- Django 4.2.7
- Django REST Framework 3.14.0
- PostgreSQL adapter (psycopg2-binary)
- django-environ for environment variables
- Celery 5.3.4 for async tasks
- Redis 5.0.1 for message broker
- django-celery-beat for periodic tasks
- Django CORS headers

Include version numbers for all packages to ensure reproducibility.
```

---

### Prompt 1.2.2: Django Settings Configuration

```
Update Django settings.py to:
1. Use django-environ for environment variables
2. Configure PostgreSQL database connection using env variables:
   - DATABASE_NAME
   - DATABASE_USER
   - DATABASE_PASSWORD
   - DATABASE_HOST
   - DATABASE_PORT
3. Add REST framework to INSTALLED_APPS
4. Configure REST framework default settings with pagination (50 items per page)
5. Set up CORS headers for development
6. Configure static and media files

Show me the complete DATABASES configuration and REST_FRAMEWORK settings.
```

---

## Phase 2: User Management System

### Prompt 2.1.1: Custom User Model

```
Create a custom Django User model in users/models.py that:

1. Extends AbstractUser
2. Includes these additional fields:
   - target_role (ForeignKey to Occupation model, nullable)
   - experience_years (IntegerField, 0-50 range, default 0)
   - learning_style (CharField with choices: visual, auditory, kinesthetic, reading_writing)
   - skill_level (CharField with choices: beginner, intermediate, advanced, expert)
   - resume_uploaded (BooleanField, default False)
   - linkedin_url (URLField, optional)
   - github_url (URLField, optional)
   - portfolio_url (URLField, optional)
   - current_company (CharField, max_length 200, optional)
   - last_active (DateTimeField, auto_now True)
   - total_time_spent (IntegerField, default 0, in seconds)
   - data_retention_date (DateTimeField, optional)

3. Include a Meta class with:
   - db_table = 'users'
   - indexes on target_role and last_active fields

4. Add a __str__ method returning username
5. Add a property method readiness_score() that returns 0 (placeholder for now)

Include all necessary imports and validators.
```

---

### Prompt 2.1.2: UserProficiency Model

```
Create a UserProficiency model in users/models.py that tracks IRT (Item Response Theory) theta parameters:

1. Fields:
   - user (ForeignKey to User, CASCADE, related_name='proficiencies')
   - skill (ForeignKey to 'skills.Skill', CASCADE, related_name='user_proficiencies')
   - theta (FloatField, default 0.0) - IRT ability parameter
   - standard_error (FloatField, default 1.0) - SE of theta estimate
   - calibration_count (IntegerField, default 0) - number of questions answered
   - last_updated (DateTimeField, auto_now True)
   - created_at (DateTimeField, auto_now_add True)

2. Meta class:
   - db_table = 'user_proficiencies'
   - unique_together = ['user', 'skill']
   - indexes on ['user', 'skill'] and ['theta']

3. Methods:
   - __str__: return f"{user.username} - {skill.preferred_label}: θ={theta:.2f}"
   - proficiency_level property: convert theta to 1-5 scale
     - theta < -0.5: level 1
     - -0.5 <= theta < 0: level 2
     - 0 <= theta < 0.5: level 3
     - 0.5 <= theta < 1.0: level 4
     - theta >= 1.0: level 5

Include docstrings explaining IRT parameters.
```

---

### Prompt 2.1.3: UserSkill Model

```
Create a UserSkill model for self-reported skills:

1. Fields:
   - user (ForeignKey to User, CASCADE, related_name='user_skills')
   - skill (ForeignKey to 'skills.Skill', CASCADE, related_name='user_skills')
   - self_assessment (IntegerField, 1-5 range, nullable, help_text='User\'s self-assessed proficiency level (1-5)')
   - created_at (DateTimeField, auto_now_add True)

2. Meta:
   - db_table = 'user_skills'
   - unique_together = ['user', 'skill']
   - index on 'user'

3. __str__ method: return f"{user.username} - {skill.preferred_label}"

Use MinValueValidator and MaxValueValidator for self_assessment field.
```

---

### Prompt 2.2.1: User Admin Interface

```
Create a comprehensive Django admin interface for the User model in users/admin.py:

1. Use @admin.register(User) decorator
2. Configure these list_display fields:
   - username
   - email
   - target_role
   - skill_level
   - experience_years
   - last_active
   - is_active

3. Add search_fields: username, email, current_company
4. Add list_filter: skill_level, learning_style, is_active, date_joined
5. Configure fieldsets for organized form display:
   - Personal Info: username, email, first_name, last_name
   - Profile: target_role, experience_years, skill_level, learning_style
   - Links: linkedin_url, github_url, portfolio_url
   - Company: current_company
   - Metadata: last_active, total_time_spent, date_joined

6. Make it readonly for last_active and date_joined
7. Add inline admin for UserProficiency (max 10 rows)

Include all necessary imports.
```

---

### Prompt 2.2.2: User Serializers

```
Create DRF serializers for User model in users/serializers.py:

1. UserSerializer (for detail view):
   - Include all fields except password, data_retention_date
   - Add read-only field 'readiness_score' from model property
   - Add nested serializer for 'proficiencies' (limit to 5)

2. UserListSerializer (for list view - lighter):
   - Only include: id, username, email, target_role, skill_level, last_active

3. UserCreateSerializer (for registration):
   - Include: username, email, password, first_name, last_name
   - Override create() method to handle password hashing:
     ```python
     def create(self, validated_data):
         user = User.objects.create_user(**validated_data)
         return user
     ```
   - Add password write-only field with min_length validator (8 chars)

4. UserProfileUpdateSerializer (for profile updates):
   - Include: target_role, experience_years, skill_level, learning_style
   - LinkedIn, GitHub, portfolio URLs
   - current_company

Include proper imports and field validators.
```

---

### Prompt 2.2.3: User ViewSets

```
Create DRF ViewSets for User management in users/views.py:

1. UserViewSet:
   - Inherit from viewsets.ModelViewSet
   - Use different serializers based on action:
     - list: UserListSerializer
     - retrieve: UserSerializer
     - create: UserCreateSerializer
     - update/partial_update: UserProfileUpdateSerializer
   
   - Add custom action for user profile: @action(detail=False, methods=['get', 'put'])
     ```python
     def me(self, request):
         # Return current authenticated user's profile
     ```
   
   - Add custom action for readiness score: @action(detail=False)
     ```python
     def readiness(self, request):
         # Return user's readiness score with breakdown
     ```

2. Add permission classes: IsAuthenticated for all actions except create
3. Override get_queryset to only show authenticated user's data for 'me' endpoint
4. Add pagination_class = PageNumberPagination

Include imports: rest_framework.viewsets, rest_framework.decorators.action, rest_framework.permissions
```

---

## Phase 3: Skills Taxonomy System

### Prompt 3.1.1: Occupation Model

```
Create an Occupation model in skills/models.py based on ESCO and O*NET taxonomies:

1. Fields:
   - esco_uri (CharField, max 255, unique, nullable, help_text='ESCO occupation URI')
   - onet_code (CharField, max 20, unique, nullable, help_text='O*NET-SOC code')
   - preferred_label (CharField, max 255, indexed, help_text='Primary job title')
   - alternative_labels (ArrayField of CharField, max 100 each, help_text='Alternative job titles')
   - description (TextField)
   - parent (ForeignKey to self, nullable, CASCADE, related_name='children')
   - created_at, updated_at (DateTimeField)

2. Meta:
   - db_table = 'occupations'
   - indexes:
     - Index on preferred_label
     - Index on onet_code
     - Index on parent
     - GinIndex on alternative_labels (for full-text search)

3. Methods:
   - __str__: return preferred_label
   - get_all_required_skills(): recursive method to get skills from parent occupations

Use django.contrib.postgres.fields.ArrayField and django.contrib.postgres.indexes.GinIndex
```

---

### Prompt 3.1.2: Skill Model

```
Create a Skill model with semantic embeddings support:

1. Fields:
   - esco_uri (CharField, max 255, unique, nullable)
   - preferred_label (CharField, max 255, indexed)
   - alternative_labels (ArrayField of CharField)
   - description (TextField)
   - skill_type (CharField with choices: 'technical', 'soft', 'knowledge')
   - prerequisites (ManyToMany to self, symmetrical=False, related_name='required_for')
   - search_vector (SearchVectorField, nullable) - for full-text search
   - created_at, updated_at (DateTimeField)

2. Meta:
   - db_table = 'skills'
   - indexes:
     - Index on preferred_label
     - Index on skill_type
     - GinIndex on alternative_labels
     - GinIndex on search_vector (for full-text search)

3. Methods:
   - __str__: return preferred_label
   - save(): override to update search_vector from preferred_label + description
   - get_prerequisite_dag(): build directed acyclic graph of prerequisites (recursive)

Use django.contrib.postgres.search.SearchVectorField
```

---

### Prompt 3.1.3: OccupationSkill Through Model

```
Create a through model for Occupation-Skill relationship:

1. Model name: OccupationSkill
2. Fields:
   - occupation (ForeignKey to Occupation, CASCADE, related_name='occupation_skills')
   - skill (ForeignKey to Skill, CASCADE, related_name='occupation_skills')
   - importance (FloatField, 0.0-1.0 range, default 0.5, help_text='Importance weight')
   - required_proficiency_theta (FloatField, default 0.0, help_text='Required IRT theta level')

3. Meta:
   - db_table = 'occupation_skills'
   - unique_together = ['occupation', 'skill']
   - index on ['occupation', 'importance']

4. __str__: return f"{occupation.preferred_label} requires {skill.preferred_label}"

Use validators: MinValueValidator(0.0), MaxValueValidator(1.0) for importance
```

---

### Prompt 3.1.4: SkillEmbedding Model

```
Create a model to store semantic embeddings for skills:

1. Model: SkillEmbedding
2. Fields:
   - skill (OneToOneField to Skill, CASCADE, related_name='embedding')
   - vector (ArrayField of FloatField, size 768, help_text='Embedding vector (e.g., from text-embedding-004)')
   - model_name (CharField, max 100, default='text-embedding-004')
   - created_at, updated_at (DateTimeField)

3. Meta:
   - db_table = 'skill_embeddings'

4. __str__: return f"Embedding for {skill.preferred_label}"

Note: ArrayField size of 768 matches common embedding dimensions. Adjust based on actual model used.
```

---

## Phase 4: Celery Task Queue Setup

### Prompt 4.1.1: Celery Configuration File

```
Create a complete Celery configuration in jobreadiness/celery.py:

1. Import os, Celery
2 Set default Django settings module
3. Create Celery app instance with name 'jobreadiness'
4. Configure from Django settings with namespace 'CELERY'
5. Enable task autodiscovery
6. Configure task queues:
   - high_priority_sync (routing_key: high_priority)
   - irt_calculation (routing_key: irt)
   - low_priority_batch (routing_key: batch)

7. Add beat schedule for periodic tasks (placeholder for now):
   - Cache cleanup: every day at midnight
   - Send batch requests: every 12 hours

8. Configure task time limits:
   - task_time_limit: 300 (5 minutes)
   - task_soft_time_limit: 240 (4 minutes)

Include proper error handling and logging configuration.
```

---

### Prompt 4.1.2: Celery Settings in Django

```
Add Celery configuration to Django settings.py:

1. Celery Broker settings:
   - CELERY_BROKER_URL: redis://localhost:6379/0 (from env)
   - CELERY_RESULT_BACKEND: redis://localhost:6379/0

2. Celery Task settings:
   - CELERY_ACCEPT_CONTENT: ['json']
   - CELERY_TASK_SERIALIZER: 'json'
   - CELERY_RESULT_SERIALIZER: 'json'
   - CELERY_TIMEZONE: 'UTC'
   - CELERY_TASK_TRACK_STARTED: True
   - CELERY_TASK_TIME_LIMIT: 30 * 60 (30 minutes)

3. Configure task routes:
   - users.tasks.*: high_priority_sync queue
   - skills.tasks.*: high_priority_sync queue
   - assessment.tasks.calculate_theta: irt_calculation queue
   - learning.tasks.generate_study_plan: low_priority_batch queue

4. Add django_celery_beat to INSTALLED_APPS

Use environment variables for Redis connection URL.
```

---

### Prompt 4.2.1: User Tasks

```
Create Celery tasks in users/tasks.py:

1. Task: send_welcome_email
   - Decorated with @shared_task
   - Parameters: user_id
   - Fetch user from database
   - Log email sending (actual implementation later)
   - Return success message

2. Task: update_user_activity
   - Parameters: user_id
   - Update user's last_active timestamp
   - Increment total_time_spent by session duration
   - Use .update() to avoid race conditions

3. Task: calculate_readiness_score
   - Parameters: user_id
   - Calculate score based on skill proficiencies (placeholder calculation)
   - Return score as dict with breakdown

Include proper error handling with try/except blocks and logging.
```

---

### Prompt 4.2.2: Skills Tasks

```
Create Celery tasks in skills/tasks.py:

1. Task: generate_skill_embeddings
   - Parameters: skill_id
   - Fetch skill from database
   - Generate embedding vector (placeholder: random vector for now)
   - Create or update SkillEmbedding record
   - Return success with embedding dimensions

2. Task: update_skill_search_vector
   - Parameters: skill_id
   - Update SearchVector field from preferred_label + description
   - Use PostgreSQL full-text search functions

3. Task: import_esco_skills_batch
   - Parameters: skills_data (list of dicts)
   - Bulk create skills from ESCO data
   - Return count of created skills
   - Use bulk_create for efficiency

Add retry logic with @task(bind=True, max_retries=3) for network calls.
```

---

## Phase 5: Database Migrations & Security

### Prompt 5.1.1: Review Migration Files

```
Guide me through reviewing Django migration files before applying them:

1. What should I check in migration files?
2. How to verify field types match expectations?
3. How to ensure indexes are created correctly?
4. How to check for potential data loss operations?
5. Show me common migration issues and how to fix them

Include examples of reviewing a migration for the User model with custom fields.
```

---

### Prompt 5.2.1: Sample Data Creation Script

```
Create a Django management command to generate sample data in users/management/commands/create_sample_data.py:

1. Create 5 sample occupations:
   - Software Developer (ONET: 15-1252.00)
   - Data Scientist (ONET: 15-2051.01)
   - Product Manager (ONET: 11-2021.00)
   - UX Designer (ONET: 27-1021.00)
   - DevOps Engineer (ONET: 15-1299.08)

2. Create 20 sample skills (mix of technical and soft skills):
   - Python, JavaScript, SQL, Docker, etc.
   - Communication, Leadership, Problem Solving, etc.

3. Link skills to occupations with importance weights

4. Create 3 sample users with different profiles

5. Use get_or_create to avoid duplicates

6. Add progress messages using self.stdout.write()

Command should handle --clear flag to delete existing sample data first.
```

---

### Prompt 5.3.1: Security Settings Configuration

```
Create comprehensive security settings for Django in settings.py:

1. Security Headers:
   - SECURE_CONTENT_TYPE_NOSNIFF = True
   - SECURE_BROWSER_XSS_FILTER = True
   - X_FRAME_OPTIONS = 'DENY'
   - SECURE_SSL_REDIRECT = not DEBUG (redirect HTTP to HTTPS in production)

2. Session Security:
   - SESSION_COOKIE_SECURE = not DEBUG
   - SESSION_COOKIE_HTTPONLY = True
   - SESSION_COOKIE_SAMESITE = 'Lax'
   - SESSION_COOKIE_AGE = 1209600 (2 weeks)

3. CSRF Protection:
   - CSRF_COOKIE_SECURE = not DEBUG
   - CSRF_COOKIE_HTTPONLY = True
   - CSRF_COOKIE_SAMESITE = 'Lax'

4. Password Validation:
   - UserAttributeSimilarityValidator
   - MinimumLengthValidator (12 characters)
   - CommonPasswordValidator
   - NumericPasswordValidator

5. CORS Settings:
   - CORS_ALLOWED_ORIGINS from environment variable
   - CORS_ALLOW_CREDENTIALS = True

Use environment variables for production vs development settings.
```

---

## Phase 6: Docker Setup

### Prompt 6.1.1: Multi-Stage Dockerfile

```
Create a multi-stage production Dockerfile for the Django application:

Stage 1 - Builder:
1. Use python:3.10-slim as base
2. Set environment variables:
   - PYTHONDONTWRITEBYTECODE=1
   - PYTHONUNBUFFERED=1
3. Install build dependencies
4. Copy requirements.txt and install Python packages
5. Install spaCy English model

Stage 2 - Final:
1. Use python:3.10-slim as base
2. Copy installed packages from builder stage
3. Create non-root user 'appuser'
4. Set working directory /app
5. Copy application code
6. Change ownership to appuser
7. Expose port 8000
8. Use gunicorn as CMD with:
   - 4 workers
   - gevent worker class
   - Bind to 0.0.0.0:8000

Add health check using curl to /health/ endpoint.
```

---

### Prompt 6.1.2: Docker Compose Configuration

```
Create a comprehensive docker-compose.yml for development with 7 services:

1. PostgreSQL (db):
   - Image: postgres:15-alpine
   - Environment: POSTGRES_DB, POSTGRES_USER, POSTGRES_PASSWORD
   - Volume: postgres_data
   - Healthcheck: pg_isready

2. Redis:
   - Image: redis:7-alpine
   - Volume: redis_data
   - Healthcheck: redis-cli ping

3. Django (web):
   - Build from Dockerfile
   - Command: python manage.py runserver 0.0.0.0:8000
   - Volumes: . mounted to /app
   - Ports: 8000:8000
   - Depends on: db, redis
   - Environment from .env file

4. Celery Worker:
   - Same build as web
   - Command: celery -A jobreadiness worker -l info
   - Depends on: db, redis, web

5. Celery Beat:
   - Same build as web
   - Command: celery -A jobreadiness beat -l info
   - Depends on: db, redis, web

6. Daphne (WebSocket):
   - Same build as web
   - Command: daphne -b 0.0.0.0 -p 8001 jobreadiness.asgi:application
   - Ports: 8001:8001

7. Nginx:
   - Image: nginx:alpine
   - Volume: ./nginx.conf:/etc/nginx/nginx.conf
   - Ports: 80:80
   - Depends on: web, daphne

Include volumes for persistent data and networks configuration.
```

---

## Phase 7: Testing & Documentation

### Prompt 7.1.1: API Testing Script

```
Create a Python script test_api.py to test all API endpoints:

1. Use requests library
2. Test these endpoints:
   - POST /api/users/ (create user)
   - GET /api/users/me/ (get current user)
   - GET /api/users/ (list users)
   - GET /api/skills/ (list skills)
   - GET /api/occupations/ (list occupations)

3. For each test:
   - Print test name
   - Make HTTP request
   - Assert status code
   - Print response (pretty JSON)
   - Print PASS/FAIL result

4. Add authentication token support

5. Use colorama for colored output (green for success, red for fail)

6. Add summary at end with total passed/failed

Make it runnable with: python test_api.py --host localhost:8000
```

---

### Prompt 7.2.1: Comprehensive README

```
Create a comprehensive README.md for the ShikshaAI project:

Structure:
1. Project Title and Logo placeholder
2. Project Description (AI-driven job readiness platform)
3. Features (bullet points):
   - User authentication
   - Skills taxonomy
   - Occupation matching
   - Async task processing
4. Tech Stack (table format)
5. Prerequisites
6. Installation (step by step):
   - Clone repository
   - Create virtual environment
   - Install dependencies
   - Setup database
   - Run migrations
   - Create superuser
7. Running the Application:
   - Development server
   - Celery worker
   - Docker compose
8. API Documentation (endpoint list)
9. Project Structure (tree format)
10. Contributing Guidelines
11. License (MIT)
12. Contact & Support

Use emoji for section headers and include code blocks with syntax highlighting.
```

---

## General AI Agent Prompts

### Debugging Errors

```
I'm getting this error in my Django project:
[paste error message]

Please help me:
1. Explain what this error means
2. Identify the root cause
3. Provide step-by-step solution
4. Show the corrected code
5. Explain how to prevent this in future

Context: I'm working on [describe what you were doing]
```

---

### Code Review

```
Review this [model/view/serializer] code for:
1. Django best practices
2. Security vulnerabilities
3. Performance optimization opportunities
4. Code readability and maintainability
5. Missing error handling

[paste your code]

Provide specific suggestions with improved code examples.
```

---

### Optimization

```
Optimize this Django queryset/view for better performance:

[paste code]

Consider:
1. N+1 query problem
2. Select_related and prefetch_related usage
3. Database indexing
4. Caching opportunities
5. Unnecessary database hits

Show before/after comparison with explanation.
```

---

## Tips for Using AI Prompts

### ✅ DO:
- Be specific about Django version and packages
- Include context about related models/views
- Ask for explanations along with code
- Request test cases for complex logic
- Ask for error handling and edge cases

### ❌ DON'T:
- Copy-paste code without understanding
- Skip testing generated code
- Ignore deprecation warnings
- Forget to add proper logging
- Blindly trust security-related code

---

## Troubleshooting Common Issues

### Issue: "No module named 'users'"
```
Ask AI: "I'm getting 'No module named users' error. I've created the users app but Django can't find it. What should I check?"
```

### Issue: Migration conflicts
```
Ask AI: "I have conflicting migrations in my Django project. How do I safely reset migrations for the users and skills apps while preserving data?"
```

### Issue: Celery worker not picking up tasks
```
Ask AI: "My Celery worker starts successfully but doesn't execute tasks. Help me debug the Celery configuration, broker connection, and task discovery."
```

---

**Remember**: AI is a tool to assist you, not replace understanding. Always review, test, and understand the generated code before using it in production!
