# Day 01: Detailed Tasks Breakdown

## Developer Assignment

- **Developer A (DA)**: Focus on Django project setup, user models, and authentication
- **Developer B (DB)**: Focus on skills taxonomy, database configuration, and Celery setup

---

## Phase 1: Project Initialization (1.5 hours)

### Task 1.1: Environment Setup
**Assigned to**: Both developers
**Duration**: 30 minutes

#### Subtasks:
- [ ] 1.1.1 Install Python 3.10+ and create virtual environment
  ```bash
  python -m venv venv
  source venv/bin/activate  # On Windows: venv\Scripts\activate
  ```
- [ ] 1.1.2 Install PostgreSQL 15+ and verify installation
  ```bash
  psql --version
  ```
- [ ] 1.1.3 Install Redis and start service
  ```bash
  redis-cli ping  # Should return "PONG"
  ```
- [ ] 1.1.4 Create project directory structure
  ```bash
  mkdir shikshaAI && cd shikshaAI
  ```

**Completion Criteria**: All dependencies installed and verified

---

### Task 1.2: Django Project Creation
**Assigned to**: DA
**Duration**: 30 minutes

#### Subtasks:
- [ ] 1.2.1 Install Django and core dependencies
  ```bash
  pip install Django==4.2.7 djangorestframework==3.14.0 psycopg2-binary==2.9.9
  ```
- [ ] 1.2.2 Create Django project
  ```bash
  django-admin startproject jobreadiness .
  ```
- [ ] 1.2.3 Create core Django apps
  ```bash
  python manage.py startapp users
  python manage.py startapp skills
  python manage.py startapp core
  ```
- [ ] 1.2.4 Register apps in `INSTALLED_APPS` in settings.py
  ```python
  INSTALLED_APPS = [
      'django.contrib.admin',
      'django.contrib.auth',
      'django.contrib.contenttypes',
      'django.contrib.sessions',
      'django.contrib.messages',
      'django.contrib.staticfiles',
      'rest_framework',
      'users',
      'skills',
      'core',
  ]
  ```

**Completion Criteria**: Django project structure created, apps registered

---

### Task 1.3: Database Configuration
**Assigned to**: DB
**Duration**: 30 minutes

#### Subtasks:
- [ ] 1.3.1 Create PostgreSQL database
  ```bash
  createdb jobreadiness
  ```
- [ ] 1.3.2 Create `.env` file in project root
  ```env
  DEBUG=True
  SECRET_KEY=your-secret-key-here-change-in-production
  DATABASE_NAME=jobreadiness
  DATABASE_USER=postgres
  DATABASE_PASSWORD=your-password
  DATABASE_HOST=localhost
  DATABASE_PORT=5432
  ```
- [ ] 1.3.3 Install `django-environ` for environment variable management
  ```bash
  pip install django-environ==0.11.2
  ```
- [ ] 1.3.4 Update `settings.py` to use PostgreSQL and environment variables
  ```python
  import environ
  
  env = environ.Env()
  environ.Env.read_env()
  
  DATABASES = {
      'default': {
          'ENGINE': 'django.db.backends.postgresql',
          'NAME': env('DATABASE_NAME'),
          'USER': env('DATABASE_USER'),
          'PASSWORD': env('DATABASE_PASSWORD'),
          'HOST': env('DATABASE_HOST'),
          'PORT': env('DATABASE_PORT'),
      }
  }
  ```

**Completion Criteria**: Database connected successfully, can run `python manage.py migrate`

---

## Phase 2: User Management System (2 hours)

### Task 2.1: Custom User Model
**Assigned to**: DA
**Duration**: 1 hour

#### Subtasks:
- [ ] 2.1.1 Create Custom User model in `users/models.py`
  - Extend AbstractUser
  - Add fields: `target_role`, `experience_years`, `learning_style`, `skill_level`
  - Add fields: `resume_uploaded`, `linkedin_url`, `github_url`
  - Add metadata fields: `last_active`, `total_time_spent`, `is_active`

- [ ] 2.1.2 Update `AUTH_USER_MODEL` in settings.py
  ```python
  AUTH_USER_MODEL = 'users.User'
  ```

- [ ] 2.1.3 Create UserProficiency model
  - ForeignKey to User, Skill
  - Fields: `theta`, `standard_error`, `calibration_count`
  - unique_together: `['user', 'skill']`

- [ ] 2.1.4 Create UserSkill model
  - ForeignKey to User, Skill
  - Fields: `self_assessment`, `created_at`
  - unique_together: `['user', 'skill']`

**File to Create/Edit**: `users/models.py`

**Completion Criteria**: Models defined, no syntax errors

---

### Task 2.2: User Admin & API
**Assigned to**: DA
**Duration**: 1 hour

#### Subtasks:
- [ ] 2.2.1 Create admin interface in `users/admin.py`
  ```python
  from django.contrib import admin
  from .models import User, UserProficiency, UserSkill
  
  @admin.register(User)
  class UserAdmin(admin.ModelAdmin):
      list_display = ('username', 'email', 'target_role', 'is_active')
      search_fields = ('username', 'email')
  ```

- [ ] 2.2.2 Create serializers in `users/serializers.py`
  ```python
  from rest_framework import serializers
  from .models import User
  
  class UserSerializer(serializers.ModelSerializer):
      class Meta:
          model = User
          fields = ['id', 'username', 'email', 'target_role', ...]
  ```

- [ ] 2.2.3 Create viewsets in `users/views.py`
  ```python
  from rest_framework import viewsets
  from .models import User
  from .serializers import UserSerializer
  
  class UserViewSet(viewsets.ModelViewSet):
      queryset = User.objects.all()
      serializer_class = UserSerializer
  ```

- [ ] 2.2.4 Create URL routes in `users/urls.py`
  ```python
  from rest_framework.routers import DefaultRouter
  from .views import UserViewSet
  
  router = DefaultRouter()
  router.register(r'users', UserViewSet)
  
  urlpatterns = router.urls
  ```

- [ ] 2.2.5 Include users URLs in main `urls.py`
  ```python
  from django.urls import path, include
  
  urlpatterns = [
      path('admin/', admin.site.urls),
      path('api/', include('users.urls')),
  ]
  ```

**Completion Criteria**: User CRUD API endpoints working, admin interface accessible

---

## Phase 3: Skills Taxonomy System (2 hours)

### Task 3.1: Skills & Occupation Models
**Assigned to**: DB
**Duration**: 1 hour

#### Subtasks:
- [ ] 3.1.1 Create Occupation model in `skills/models.py`
  - Fields: `esco_uri`, `onet_code`, `preferred_label`, `alternative_labels`
  - Fields: `description`, `parent` (self-referencing FK)
  - ArrayField for `alternative_labels`
  - GIN index on `alternative_labels`

- [ ] 3.1.2 Create Skill model
  - Fields: `esco_uri`, `preferred_label`, `alternative_labels`
  - Fields: `description`, `skill_type` (technical/soft/knowledge)
  - ArrayField for `alternative_labels` and `embeddings`
  - Self-referencing ManyToMany for `prerequisites`

- [ ] 3.1.3 Create OccupationSkill through model
  - ForeignKey to Occupation, Skill
  - Fields: `importance` (0-1), `required_proficiency_theta`
  - unique_together: `['occupation', 'skill']`

- [ ] 3.1.4 Create SkillEmbedding model
  - OneToOne to Skill
  - ArrayField for `vector` (embedding dimensions)
  - Fields: `model_name`, `created_at`

**File to Create/Edit**: `skills/models.py`

**Completion Criteria**: All models defined with proper relationships and indexes

---

### Task 3.2: Skills Admin & Data Import
**Assigned to**: DB
**Duration**: 1 hour

#### Subtasks:
- [ ] 3.2.1 Create admin interface in `skills/admin.py`
  ```python
  @admin.register(Occupation)
  class OccupationAdmin(admin.ModelAdmin):
      list_display = ('preferred_label', 'onet_code', 'parent')
      search_fields = ('preferred_label', 'onet_code')
  
  @admin.register(Skill)
  class SkillAdmin(admin.ModelAdmin):
      list_display = ('preferred_label', 'skill_type')
      list_filter = ('skill_type',)
      search_fields = ('preferred_label',)
  ```

- [ ] 3.2.2 Create management command structure
  ```bash
  mkdir -p skills/management/commands
  touch skills/management/__init__.py
  touch skills/management/commands/__init__.py
  ```

- [ ] 3.2.3 Create placeholder import command `skills/management/commands/import_esco.py`
  ```python
  from django.core.management.base import BaseCommand
  
  class Command(BaseCommand):
      help = 'Import ESCO taxonomy data'
      
      def handle(self, *args, **options):
          self.stdout.write('ESCO import command created - implementation pending')
  ```

- [ ] 3.2.4 Create basic API endpoints in `skills/views.py`
  ```python
  class OccupationViewSet(viewsets.ReadOnlyModelViewSet):
      queryset = Occupation.objects.all()
      serializer_class = OccupationSerializer
      
  class SkillViewSet(viewsets.ReadOnlyModelViewSet):
      queryset = Skill.objects.all()
      serializer_class = SkillSerializer
  ```

**Completion Criteria**: Skills taxonomy structure ready, admin interface working

---

## Phase 4: Celery Task Queue Setup (1.5 hours)

### Task 4.1: Celery Configuration
**Assigned to**: DB
**Duration**: 45 minutes

#### Subtasks:
- [ ] 4.1.1 Install Celery and Redis dependencies
  ```bash
  pip install celery==5.3.4 redis==5.0.1 django-celery-beat==2.5.0
  ```

- [ ] 4.1.2 Create `jobreadiness/celery.py`
  ```python
  import os
  from celery import Celery
  
  os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'jobreadiness.settings')
  
  app = Celery('jobreadiness')
  app.config_from_object('django.conf:settings', namespace='CELERY')
  app.autodiscover_tasks()
  ```

- [ ] 4.1.3 Update `jobreadiness/__init__.py`
  ```python
  from .celery import app as celery_app
  
  __all__ = ('celery_app',)
  ```

- [ ] 4.1.4 Add Celery settings to `settings.py`
  ```python
  CELERY_BROKER_URL = 'redis://localhost:6379/0'
  CELERY_RESULT_BACKEND = 'redis://localhost:6379/0'
  CELERY_ACCEPT_CONTENT = ['json']
  CELERY_TASK_SERIALIZER = 'json'
  CELERY_RESULT_SERIALIZER = 'json'
  ```

**Completion Criteria**: Celery configured, can start worker

---

### Task 4.2: Sample Celery Tasks
**Assigned to**: DB
**Duration**: 45 minutes

#### Subtasks:
- [ ] 4.2.1 Create `users/tasks.py`
  ```python
  from celery import shared_task
  
  @shared_task
  def send_welcome_email(user_id):
      print(f"Sending welcome email to user {user_id}")
      return f"Email sent to user {user_id}"
  ```

- [ ] 4.2.2 Create `skills/tasks.py`
  ```python
  @shared_task
  def generate_skill_embeddings(skill_id):
      print(f"Generating embeddings for skill {skill_id}")
      return f"Embeddings generated for skill {skill_id}"
  ```

- [ ] 4.2.3 Test Celery task execution
  ```python
  # In Django shell
  from users.tasks import send_welcome_email
  result = send_welcome_email.delay(1)
  result.get()
  ```

- [ ] 4.2.4 Add `django-celery-beat` to INSTALLED_APPS
  ```python
  INSTALLED_APPS = [
      ...
      'django_celery_beat',
  ]
  ```

**Completion Criteria**: Sample tasks execute successfully in Celery worker

---

## Phase 5: Database Migrations & Security (1.5 hours)

### Task 5.1: Run Migrations
**Assigned to**: DA
**Duration**: 30 minutes

#### Subtasks:
- [ ] 5.1.1 Create migrations for all models
  ```bash
  python manage.py makemigrations users
  python manage.py makemigrations skills
  ```

- [ ] 5.1.2 Review migration files
  - Check field types are correct
  - Verify indexes are created
  - Ensure unique_together constraints are present

- [ ] 5.1.3 Apply migrations to database
  ```bash
  python manage.py migrate
  ```

- [ ] 5.1.4 Verify tables in PostgreSQL
  ```bash
  psql jobreadiness
  \dt  # List all tables
  \d users  # Describe users table
  ```

**Completion Criteria**: All migrations applied, tables exist in database

---

### Task 5.2: Create Superuser & Test Data
**Assigned to**: DA
**Duration**: 30 minutes

#### Subtasks:
- [ ] 5.2.1 Create Django superuser
  ```bash
  python manage.py createsuperuser
  ```

- [ ] 5.2.2 Create sample data script `scripts/create_sample_data.py`
  ```python
  from users.models import User
  from skills.models import Skill, Occupation
  
  # Create sample occupation
  occ = Occupation.objects.create(
      onet_code='15-1252.00',
      preferred_label='Software Developer',
      description='Develop software applications'
  )
  
  # Create sample skills
  skill1 = Skill.objects.create(
      preferred_label='Python Programming',
      skill_type='technical',
      description='Programming language'
  )
  ```

- [ ] 5.2.3 Run sample data creation
  ```bash
  python scripts/create_sample_data.py
  ```

- [ ] 5.2.4 Verify data in admin interface
  - Login to `http://localhost:8000/admin/`
  - Check users, skills, occupations exist

**Completion Criteria**: Admin accessible with sample data visible

---

### Task 5.3: Security Configuration
**Assigned to**: Both
**Duration**: 30 minutes

#### Subtasks:
- [ ] 5.3.1 Update `settings.py` security settings
  ```python
  # SECURITY WARNING: don't run with debug turned on in production!
  DEBUG = env.bool('DEBUG', default=False)
  
  ALLOWED_HOSTS = env.list('ALLOWED_HOSTS', default=['localhost', '127.0.0.1'])
  
  # CSRF
  CSRF_COOKIE_SECURE = not DEBUG
  SESSION_COOKIE_SECURE = not DEBUG
  ```

- [ ] 5.3.2 Create `.gitignore` file
  ```
  venv/
  *.pyc
  __pycache__/
  .env
  db.sqlite3
  *.log
  staticfiles/
  media/
  ```

- [ ] 5.3.3 Create `requirements.txt`
  ```bash
  pip freeze > requirements.txt
  ```

- [ ] 5.3.4 Create `.env.example` file
  ```env
  DEBUG=True
  SECRET_KEY=your-secret-key-here
  DATABASE_NAME=jobreadiness
  DATABASE_USER=postgres
  DATABASE_PASSWORD=your-password
  DATABASE_HOST=localhost
  DATABASE_PORT=5432
  ```

**Completion Criteria**: Security settings configured, secrets protected

---

## Phase 6: Docker Setup (Optional - 1 hour)

### Task 6.1: Dockerfile & Docker Compose
**Assigned to**: DB
**Duration**: 1 hour

#### Subtasks:
- [ ] 6.1.1 Create `Dockerfile`
  ```dockerfile
  FROM python:3.10-slim
  
  WORKDIR /app
  
  COPY requirements.txt .
  RUN pip install -r requirements.txt
  
  COPY . .
  
  CMD ["gunicorn", "jobreadiness.wsgi:application", "--bind", "0.0.0.0:8000"]
  ```

- [ ] 6.1.2 Create `docker-compose.yml`
  ```yaml
  version: '3.8'
  
  services:
    db:
      image: postgres:15
      environment:
        POSTGRES_DB: jobreadiness
        POSTGRES_USER: postgres
        POSTGRES_PASSWORD: postgres
      ports:
        - "5432:5432"
    
    redis:
      image: redis:7
      ports:
        - "6379:6379"
    
    web:
      build: .
      command: python manage.py runserver 0.0.0.0:8000
      volumes:
        - .:/app
      ports:
        - "8000:8000"
      depends_on:
        - db
        - redis
  ```

- [ ] 6.1.3 Test Docker build
  ```bash
  docker-compose build
  ```

- [ ] 6.1.4 Start services
  ```bash
  docker-compose up
  ```

**Completion Criteria**: Application runs in Docker containers

---

## Phase 7: Testing & Documentation (1 hour)

### Task 7.1: Manual Testing
**Assigned to**: Both
**Duration**: 30 minutes

#### Subtasks:
- [ ] 7.1.1 Test user registration via API
  ```bash
  curl -X POST http://localhost:8000/api/users/ \
    -H "Content-Type: application/json" \
    -d '{"username": "testuser", "email": "test@example.com", "password": "test123"}'
  ```

- [ ] 7.1.2 Test user list endpoint
  ```bash
  curl http://localhost:8000/api/users/
  ```

- [ ] 7.1.3 Test skills endpoint
  ```bash
  curl http://localhost:8000/api/skills/
  ```

- [ ] 7.1.4 Test admin interface
  - Login to admin
  - Create a user manually
  - Create a skill manually
  - Create an occupation manually

**Completion Criteria**: All endpoints return expected responses

---

### Task 7.2: Documentation
**Assigned to**: DA
**Duration**: 30 minutes

#### Subtasks:
- [ ] 7.2.1 Create README.md
  - Project description
  - Installation instructions
  - How to run the server
  - API endpoints list

- [ ] 7.2.2 Document environment variables in `.env.example`

- [ ] 7.2.3 Create `SETUP.md` with step-by-step setup guide

- [ ] 7.2.4 Add inline comments to complex code sections

**Completion Criteria**: Documentation complete and clear

---

## Summary Checklist

### Must Complete Today
- [x] Django project created and running
- [x] PostgreSQL connected successfully
- [x] User model with authentication working
- [x] Skills and Occupation models created
- [x] Database migrations applied
- [x] Admin interface accessible
- [x] Celery worker running
- [x] Sample data created
- [x] Basic API endpoints working

### Good to Have (If Time Permits)
- [ ] Docker setup complete
- [ ] Comprehensive test suite
- [ ] API documentation with Swagger
- [ ] Frontend scaffolding

---

## Developer Sync Points

### Morning Standup (15 min)
- Review tasks for the day
- Assign Phase 1 tasks
- Resolve any blockers

### Mid-Day Check-in (15 min)
- Progress update on Phases 1-3
- Code review of completed tasks
- Adjust timeline if needed

### End-of-Day Review (30 min)
- Demo completed features
- Code review and merge
- Plan for Day 2
- Document any issues

---

## Time Tracking

| Phase | Estimated | Actual | Notes |
|-------|-----------|--------|-------|
| Phase 1: Initialization | 1.5h | | |
| Phase 2: User System | 2h | | |
| Phase 3: Skills System | 2h | | |
| Phase 4: Celery Setup | 1.5h | | |
| Phase 5: Migrations | 1.5h | | |
| Phase 6: Docker (Optional) | 1h | | |
| Phase 7: Testing | 1h | | |
| **Total** | **8-9h** | | |

---

**Notes**:
- Each developer works in parallel on assigned tasks
- Regular commits to version control after each subtask
- Pull requests reviewed by peer before merging
- All tests must pass before marking task complete
