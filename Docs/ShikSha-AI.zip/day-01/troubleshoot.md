# Day 01: Troubleshooting Guide

This document contains solutions to common issues you may encounter during Day 1 implementation.

---

## Table of Contents
1. [Environment Setup Issues](#environment-setup-issues)
2. [Django Configuration Problems](#django-configuration-problems)
3. [Database Connection Errors](#database-connection-errors)
4. [Model & Migration Issues](#model--migration-issues)
5. [Celery Task Queue Problems](#celery-task-queue-problems)
6. [Docker & Container Issues](#docker--container-issues)
7. [API Endpoint Errors](#api-endpoint-errors)
8. [Import & Module Errors](#import--module-errors)

---

## Environment Setup Issues

### ❌ Problem: `python: command not found` or wrong Python version

**Symptoms:**
```bash
$ python --version
-bash: python: command not found
```

**Solution:**
```bash
# Check if python3 is available
python3 --version

# Create alias (add to ~/.bashrc or ~/.zshrc)
alias python=python3
alias pip=pip3

# Or use python3 explicitly
python3 -m venv venv
```

**Prevention:** Always use `python3` explicitly on systems where Python 2 might be installed.

---

### ❌ Problem: Virtual environment activation issues

**Symptoms:**
```bash
$ source venv/bin/activate
-bash: venv/bin/activate: No such file or directory
```

**Solution:**
```bash
# Make sure you created the virtual environment first
python3 -m venv venv

# For Windows (Command Prompt)
venv\Scripts\activate.bat

# For Windows (PowerShell)
venv\Scripts\Activate.ps1

# For Linux/Mac
source venv/bin/activate

# Verify activation (should show venv path)
which python
```

**Prevention:** Always create venv before trying to activate it.

---

### ❌ Problem: `pip install` fails with permission errors

**Symptoms:**
```bash
ERROR: Could not install packages due to an EnvironmentError: [Errno 13] Permission denied
```

**Solution:**
```bash
# DON'T use sudo with pip in virtual environment

# Instead, ensure virtual environment is activated
source venv/bin/activate

# Verify you're in venv
which pip  # Should show path with 'venv' in it

# Then install
pip install -r requirements.txt

# If still fails, try upgrading pip first
pip install --upgrade pip
```

**Prevention:** Never use `sudo pip install`. Always work within virtual environments.

---

## Django Configuration Problems

### ❌ Problem: `SECRET_KEY` not found error

**Symptoms:**
```python
django.core.exceptions.ImproperlyConfigured: The SECRET_KEY setting must not be empty.
```

**Solution:**
```bash
# 1. Create .env file if it doesn't exist
touch .env

# 2. Generate a new secret key
python -c "from django.core.management.utils import get_random_secret_key; print(get_random_secret_key())"

# 3. Add to .env file
echo "SECRET_KEY=your-generated-key-here" >> .env

# 4. Verify settings.py has this code:
# import environ
# env = environ.Env()
# environ.Env.read_env()
# SECRET_KEY = env('SECRET_KEY')
```

**Prevention:** Always create `.env` file from `.env.example` template before running.

---

### ❌ Problem: `ImportError: No module named 'environ'`

**Symptoms:**
```python
ImportError: No module named 'environ'
```

**Solution:**
```bash
# Install django-environ
pip install django-environ

# Verify installation
pip list | grep environ

# Add to requirements.txt
echo "django-environ==0.11.2" >> requirements.txt
```

**Prevention:** Install all dependencies from requirements.txt before starting development.

---

### ❌ Problem: App not in `INSTALLED_APPS` error

**Symptoms:**
```python
RuntimeError: Model class users.models.User doesn't declare an explicit app_label and isn't in an application in INSTALLED_APPS.
```

**Solution:**
```python
# In settings.py, add your apps to INSTALLED_APPS:

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    
    # Third-party apps
    'rest_framework',
    'corsheaders',
    'django_celery_beat',
    
    # Your apps
    'users.apps.UsersConfig',  # or just 'users'
    'skills.apps.SkillsConfig',  # or just 'skills'
    'core',
]
```

**Prevention:** Always add new apps to `INSTALLED_APPS` immediately after creation.

---

## Database Connection Errors

### ❌ Problem: PostgreSQL connection refused

**Symptoms:**
```python
django.db.utils.OperationalError: could not connect to server: Connection refused
```

**Solution:**
```bash
# 1. Check if PostgreSQL is running
# macOS
brew services list | grep postgresql
brew services start postgresql@15

# Linux
sudo systemctl status postgresql
sudo systemctl start postgresql

# Windows
# Start from Services app or:
net start postgresql-x64-15

# 2. Verify connection manually
psql -U postgres -h localhost

# 3. Check .env settings match PostgreSQL config
DATABASE_HOST=localhost  # not 127.0.0.1 if using socket
DATABASE_PORT=5432
DATABASE_USER=postgres
DATABASE_PASSWORD=yourpassword
```

**Prevention:** Start PostgreSQL service before running Django.

---

### ❌ Problem: Database does not exist

**Symptoms:**
```python
django.db.utils.OperationalError: FATAL: database "jobreadiness" does not exist
```

**Solution:**
```bash
# Create database
createdb jobreadiness

# Or using psql
psql -U postgres
CREATE DATABASE jobreadiness;
\q

# Verify database exists
psql -U postgres -l | grep jobreadiness
```

**Prevention:** Create database before running migrations.

---

### ❌ Problem: Peer authentication failed

**Symptoms:**
```python
django.db.utils.OperationalError: FATAL: Peer authentication failed for user "postgres"
```

**Solution:**
```bash
# Edit PostgreSQL config file
# Location varies by OS:
# Ubuntu/Debian: /etc/postgresql/15/main/pg_hba.conf
# macOS (Homebrew): /usr/local/var/postgres/pg_hba.conf

# Change this line:
FROM: local   all   postgres   peer
TO:   local   all   postgres   md5

# Restart PostgreSQL
sudo systemctl restart postgresql  # Linux
brew services restart postgresql   # macOS

# Set postgres user password if needed
psql -U postgres
ALTER USER postgres WITH PASSWORD 'yourpassword';
\q
```

**Prevention:** Configure PostgreSQL authentication before starting Django project.

---

## Model & Migration Issues

### ❌ Problem: No changes detected when creating migrations

**Symptoms:**
```bash
$ python manage.py makemigrations
No changes detected
```

**Solution:**
```bash
# 1. Ensure app is in INSTALLED_APPS
# Check settings.py

# 2. Specify app name explicitly
python manage.py makemigrations users
python manage.py makemigrations skills

# 3. Check if __init__.py exists in app directory
ls users/__init__.py

# 4. Check model syntax for errors
python manage.py check

# 5. Create migrations directory if missing
mkdir -p users/migrations
touch users/migrations/__init__.py
```

**Prevention:** Always add apps to `INSTALLED_APPS` and ensure proper app structure.

---

### ❌ Problem: Circular dependency in migrations

**Symptoms:**
```python
django.db.migrations.exceptions.CircularDependencyError
```

**Solution:**
```bash
# Option 1: Squash migrations
python manage.py squashmigrations users 0001 0005

# Option 2: Reset migrations (DEVELOPMENT ONLY - LOSES DATA)
# 1. Delete migration files (keep __init__.py)
rm users/migrations/0*.py
rm skills/migrations/0*.py

# 2. Drop database
dropdb jobreadiness
createdb jobreadiness

# 3. Recreate migrations
python manage.py makemigrations
python manage.py migrate

# Option 3: Fix dependencies manually
# Edit migration files to correct the dependencies array
```

**Prevention:** 
- Design models carefully before creating migrations
- Avoid circular foreign key relationships
- Use `null=True` for ForeignKeys initially

---

### ❌ Problem: Field doesn't have a default value

**Symptoms:**
```python
django.db.utils.IntegrityError: (1364, "Field 'target_role' doesn't have a default value")
```

**Solution:**
```python
# In models.py, add one of these to your field:

# Option 1: Make it nullable
target_role = models.ForeignKey(
    'skills.Occupation',
    null=True,  # Add this
    blank=True,  # Add this for forms
    on_delete=models.SET_NULL
)

# Option 2: Provide a default
status = models.CharField(
    max_length=20,
    default='active'  # Add this
)

# Then make and apply new migration
python manage.py makemigrations
python manage.py migrate
```

**Prevention:** Always consider nullable vs required fields when designing models.

---

### ❌ Problem: `AUTH_USER_MODEL` refers to model that has not been installed

**Symptoms:**
```python
ValueError: The field users.User.target_role was declared with a lazy reference to 'skills.occupation'
```

**Solution:**
```python
# Ensure proper app ordering in INSTALLED_APPS
INSTALLED_APPS = [
    ...
    'users',
    'skills',  # skills must be before users if users references skills
]

# In models, use proper model references:
# Use string reference for models not yet imported
target_role = models.ForeignKey(
    'skills.Occupation',  # String reference
    on_delete=models.SET_NULL,
    null=True
)

# Or import after model definition
from django.apps import apps
Occupation = apps.get_model('skills', 'Occupation')
```

**Prevention:** Use string references for cross-app model relationships.

---

## Celery Task Queue Problems

### ❌ Problem: Celery worker not starting

**Symptoms:**
```bash
$ celery -A jobreadiness worker -l info
Error: Unable to load celery application.
```

**Solution:**
```bash
# 1. Check if celery.py exists in project directory
ls jobreadiness/celery.py

# 2. Verify __init__.py imports celery app
# In jobreadiness/__init__.py:
from .celery import app as celery_app
__all__ = ('celery_app',)

# 3. Check Redis is running
redis-cli ping  # Should return "PONG"

# 4. Start Redis if not running
# macOS
brew services start redis

# Linux
sudo systemctl start redis

# Windows
# Start from Services

# 5. Try starting with explicit app location
celery -A jobreadiness.celery_app worker --loglevel=info
```

**Prevention:** Ensure Celery configuration is complete before starting worker.

---

### ❌ Problem: Tasks not being discovered

**Symptoms:**
```python
celery.exceptions.NotRegistered: 'users.tasks.send_welcome_email'
```

**Solution:**
```python
# 1. Ensure tasks.py exists in app directory
ls users/tasks.py

# 2. Check task is decorated correctly
from celery import shared_task

@shared_task  # Must have this decorator
def send_welcome_email(user_id):
    pass

# 3. Verify autodiscover_tasks in celery.py
app.autodiscover_tasks()

# 4. Explicitly configure task modules in settings.py
CELERY_IMPORTS = (
    'users.tasks',
    'skills.tasks',
)

# 5. Restart Celery worker after code changes
# Ctrl+C to stop, then restart
celery -A jobreadiness worker -l info
```

**Prevention:** Always use `@shared_task` decorator and restart worker after changes.

---

### ❌ Problem: Redis connection failed

**Symptoms:**
```python
redis.exceptions.ConnectionError: Error 111 connecting to localhost:6379. Connection refused.
```

**Solution:**
```bash
# 1. Start Redis
# macOS
brew services start redis

# Linux
sudo systemctl start redis
sudo systemctl enable redis  # Auto-start on boot

# Docker
docker run -d -p 6379:6379 redis:7-alpine

# 2. Test connection
redis-cli ping

# 3. Check if Redis is listening on correct port
netstat -an | grep 6379

# 4. Update CELERY_BROKER_URL in settings.py
CELERY_BROKER_URL = env('CELERY_BROKER_URL', default='redis://localhost:6379/0')
```

**Prevention:** Start Redis before starting Celery worker.

---

## Docker & Container Issues

### ❌ Problem: Docker daemon not running

**Symptoms:**
```bash
Cannot connect to the Docker daemon. Is the docker daemon running?
```

**Solution:**
```bash
# Start Docker Desktop (macOS/Windows)
# Or start Docker service (Linux)
sudo systemctl start docker

# Verify Docker is running
docker ps

# Add your user to docker group (Linux) to avoid sudo
sudo usermod -aG docker $USER
# Log out and back in for changes to take effect
```

**Prevention:** Start Docker Desktop before running docker commands.

---

### ❌ Problem: Port already in use

**Symptoms:**
```
Error starting userland proxy: listen tcp4 0.0.0.0:8000: bind: address already in use
```

**Solution:**
```bash
# Find process using port 8000
# Linux/macOS
lsof -i :8000
# Or
netstat -vanp tcp | grep 8000

# Windows
netstat -ano | findstr :8000

# Kill the process
kill -9 <PID>

# Or use different port in docker-compose.yml
ports:
  - "8001:8000"  # Map host 8001 to container 8000
```

**Prevention:** Stop running services before starting Docker containers.

---

### ❌ Problem: Docker build fails on requirements install

**Symptoms:**
```
ERROR: Could not find a version that satisfies the requirement xyz
```

**Solution:**
```dockerfile
# Update Dockerfile to install build dependencies

FROM python:3.10-slim

# Install system dependencies
RUN apt-get update && apt-get install -y \
    gcc \
    postgresql-client \
    && rm -rf /var/lib/apt/lists/*

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Rest of Dockerfile...
```

**Prevention:** Include all build dependencies in Dockerfile.

---

## API Endpoint Errors

### ❌ Problem: 404 Not Found for API endpoints

**Symptoms:**
```bash
$ curl http://localhost:8000/api/users/
{"detail":"Not found."}
```

**Solution:**
```python
# 1. Check URL configuration in main urls.py
urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/', include('users.urls')),  # Must have this
]

# 2. Verify users/urls.py exists and is configured
from rest_framework.routers import DefaultRouter
from .views import UserViewSet

router = DefaultRouter()
router.register(r'users', UserViewSet)

urlpatterns = router.urls

# 3. Check URL patterns
python manage.py show_urls  # Requires django-extensions

# 4. Test different URL formats
curl http://localhost:8000/api/users/  # With trailing slash
curl http://localhost:8000/api/users   # Without trailing slash
```

**Prevention:** Follow DRF conventions for URL patterns.

---

### ❌ Problem: CSRF token missing or incorrect

**Symptoms:**
```json
{"detail":"CSRF Failed: CSRF token missing or incorrect."}
```

**Solution:**
```python
# Option 1: Disable CSRF for API (not recommended for production)
# In views.py
from django.views.decorators.csrf import csrf_exempt

@csrf_exempt
def my_view(request):
    pass

# Option 2: Use DRF's authentication classes
# In settings.py
REST_FRAMEWORK = {
    'DEFAULT_AUTHENTICATION_CLASSES': [
        'rest_framework.authentication.SessionAuthentication',
        'rest_framework.authentication.TokenAuthentication',
    ],
}

# Option 3: Send CSRF token in header
# In JavaScript:
fetch('/api/endpoint/', {
    headers: {
        'X-CSRFToken': getCookie('csrftoken')
    }
})

# Option 4: Exempt DRF views from CSRF
# In settings.py
REST_FRAMEWORK = {
    'DEFAULT_AUTHENTICATION_CLASSES': [
        'rest_framework.authentication.TokenAuthentication',  # Remove Session
    ],
}
```

**Prevention:** Use proper authentication methods for APIs.

---

### ❌ Problem: JSON decode error

**Symptoms:**
```python
json.decoder.JSONDecodeError: Expecting value: line 1 column 1 (char 0)
```

**Solution:**
```bash
# Ensure Content-Type header is set
curl -X POST http://localhost:8000/api/users/ \
  -H "Content-Type: application/json" \  # Add this
  -d '{"username":"test","email":"test@example.com"}'

# Check request body is valid JSON
# Use online JSON validator

# In Python requests:
import requests
response = requests.post(
    'http://localhost:8000/api/users/',
    json={"username": "test"},  # Use json parameter
    headers={'Content-Type': 'application/json'}
)
```

**Prevention:** Always set Content-Type header for JSON requests.

---

## Import & Module Errors

### ❌ Problem: `ModuleNotFoundError: No module named 'users'`

**Symptoms:**
```python
ModuleNotFoundError: No module named 'users'
```

**Solution:**
```bash
# 1. Verify app directory structure
ls users/
# Should have: __init__.py, models.py, views.py, apps.py

# 2. Check __init__.py exists
touch users/__init__.py

# 3. Verify PYTHONPATH includes project root
echo $PYTHONPATH

# 4. Add project root to Python path
export PYTHONPATH="${PYTHONPATH}:/path/to/shikshaAI"

# 5. Use python manage.py instead of python3
python manage.py runserver
```

**Prevention:** Always create `__init__.py` in every package directory.

---

### ❌ Problem: Circular import error

**Symptoms:**
```python
ImportError: cannot import name 'User' from partially initialized module 'users.models'
```

**Solution:**
```python
 # Option 1: Use string references
from django.conf import settings

class UserProfile(models.Model):
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,  # String reference
        on_delete=models.CASCADE
    )

# Option 2: Import inside function/method
def my_function():
    from users.models import User  # Import here, not at top
    user = User.objects.first()

# Option 3: Use apps.get_model
from django.apps import apps

def my_function():
    User = apps.get_model('users', 'User')
```

**Prevention:** Avoid circular dependencies by using string references or late imports.

---

## Emergency Recovery

### 🆘 Complete Reset (Last Resort - DEVELOPMENT ONLY)

```bash
#!/bin/bash
# This will DELETE ALL DATA - use only in development

echo "⚠️  WARNING: This will delete all data!"
read -p "Are you sure? (yes/no): " confirm

if [ "$confirm" = "yes" ]; then
    # Stop all services
    docker-compose down -v
    
    # Remove virtual environment
    rm -rf venv
    
    # Remove database
    dropdb jobreadiness 2>/dev/null || true
    
    # Remove migration files
    find . -path "*/migrations/*.py" -not -name "__init__.py" -delete
    find . -path "*/migrations/*.pyc" -delete
    
    # Recreate everything
    python3 -m venv venv
    source venv/bin/activate
    pip install -r requirements.txt
    createdb jobreadiness
    python manage.py makemigrations
    python manage.py migrate
    python manage.py createsuperuser
    
    echo "✅ Fresh start complete!"
else
    echo "❌ Reset cancelled"
fi
```

Save as `reset_dev.sh` and run with `bash reset_dev.sh`

---

## Getting Help

### Before Asking for Help

1. **Check error message carefully** - Often tells you exactly what's wrong
2. **Read traceback from bottom to top** - Last line is usually the actual error
3. **Search error on Google** - Most errors have been encountered before
4. **Check Django/package version** - Some errors are version-specific

### Where to Get Help

- **Django Documentation**: https://docs.djangoproject.com/
- **Stack Overflow**: Search for error message
- **Django Forum**: https://forum.djangoproject.com/
- **Reddit**: r/django
- **Discord**: Django Discord server

### How to Ask for Help

Include:
1. **Exact error message** with full traceback
2. **What you were trying to do**
3. **What you've already tried**
4. **Relevant code snippets**
5. **Django version** and **Python version**
6. **Operating system**

---

**Remember:** Most errors are simple configuration issues. Take a deep breath, read the error carefully, and work through it systematically!
